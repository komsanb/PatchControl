window.mocha.setup({
  timeout: 5000
});
